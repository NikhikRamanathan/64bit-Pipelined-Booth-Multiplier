ArXiv/source package for:
Evidence-Traceable PPA Analysis of 64-bit Array, Radix-4 Booth, and Dadda Multipliers Using an Open-Source SKY130 Flow

Author: Nikhil Ramanathan

This package contains:
- main.tex
- figures/*.png

The compiled PDF was generated as main.pdf and is provided separately for review.

Public code and evidence repository:
https://github.com/NikhilRamanathan/64bit-Multiplier-Architecture

Corrected regenerated power commit:
c2464d9 - Regenerate power estimates from final mapped netlists

Final reported values in this manuscript:
- Array: 14,670 cells, 170,235.769600 mapped area, 89.8478 ns delay, 11.13 MHz estimated Fmax, -79.8478 ns slack, 4.03 mW power
- Radix-4 Booth: 14,029 cells, 122,304.800000 mapped area, 62.6285 ns delay, 15.97 MHz estimated Fmax, -52.6285 ns slack, 3.34 mW power
- Dadda: 12,744 cells, 149,170.566400 mapped area, 71.4395 ns delay, 14.00 MHz estimated Fmax, -61.4395 ns slack, 3.49 mW power

Power values are regenerated post-synthesis OpenROAD estimates from the final SKY130-mapped netlists using a uniform activity setup. They are not post-layout signoff power values.

The separate evidence package generated from the repository is:
64bit_multiplier_evidence_package.zip

That package should contain the raw area reports, raw timing reports, regenerated power reports, mapped netlists, and scripts from the repository. The public repository URL above is also embedded in the manuscript's Code and Evidence Availability section.
